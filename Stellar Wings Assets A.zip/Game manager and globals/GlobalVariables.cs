﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// purely used for this "pseudo" global variables
public class GlobalVariables : MonoBehaviour
{
    public double lowMaterialAmount;
    public double mediumMaterialAmount;
    public double highMaterialAmount;

    public int playerHealth;        // Holds the player's health.
    public int shipScrapsAmount;    // This holds the number of collected scraps.
    public int damageLevel;         // Stores how many times the user bought damage upgrades.
    public int shieldLevel;         // Stores how many times the user bought shield upgrades.
    public float damageModifier;    // This holds the damage scaling based on upgrades.
    public float shieldModifier;    // This holds how much damage the player will resist.

    public float bulletDamage;      // These hold the base damage of the weapons.
    public float rocketDamage;
    public float shrapnelDamage;
    public float laserDamage;

    public int evilHealth;        // This stores the enemy's maximum health.
    public int evilDamage;        // This stores damage from the evil bullet.

    public int currentFire;         // This holds which gun the player is using.
    public float reloadTime;        // This holds how long the gun takes to reload.
    public int score;               // Score is measured by seconds spent in-game + scrap count.

    void Start()
    {
        lowMaterialAmount = 0;
        mediumMaterialAmount = 0;
        highMaterialAmount = 0;

        shipScrapsAmount = 0;   // Sets scrap count to 0 at start of game.
        damageLevel = 0;        // Sets damage upgrade count to 0.
        shieldLevel = 0;        // Sets shield upgrade count to 0.
        damageModifier = 1;     // With every upgrade, this increases by 5%.
        shieldModifier = 1;     // With every upgrade, this decreases by 5%.

        bulletDamage = 300;     // Sets the default damage for all projectiles.
        rocketDamage = 1000;
        shrapnelDamage = 200;
        laserDamage = 600;

        evilHealth = 1000;      // Sets a base.
        evilDamage = 200;

        currentFire = 1;        // Sets the default gun to regular bullets.
        reloadTime = 0.25f;      // Sets the default reload to regular bullets.
        score = 0;              // Sets score to 0 by default.

        float firstCall = 1.0f;
        float nextCall = 1.0f;
        InvokeRepeating("scoreUp", firstCall, nextCall);    // Adds 1 to score every second.
    }

    void scoreUp()
    {
        score++;    // Increments by 1.
    }
}
