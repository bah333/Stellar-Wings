﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class evilFire : MonoBehaviour
{
    public GameObject Evl;      // Holds evil bullet prefab.
    public float evlSpd;        // Holds evil bullet speed.
}
