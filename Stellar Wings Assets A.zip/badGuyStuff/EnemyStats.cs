﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    // Maximum health and damage values, these will scale up
    public int maxHealth;
    public int maxDamage;

    // Current health and damage at whatever time
    int currentHealth;
    int currentDamage;

    // Values to scale health and damage
    public float scaleHealth;
    public float scaleDamage;

    // Countdown timer until health and damage is scaled up
    float timeUntilScale;
    public float baseTimeAmount;

    // Damage taken when colliding with an asteroid or other ships
    public float asteroidDamage;
    public float shipDamage;

    // For global variables
    GameObject globalObject;
    GlobalVariables globVars;

    // I don't even know what this does. It grabs the transform once on entry and does nothing else.
    Transform thisEnemy;

    GameObject leftTurret;  // Holds the turret locations.
    evilFire lTurretVars;   // Holds the turret variables.
    GameObject rightTurret;
    evilFire rTurretVars;

    // For invincibility upon spawn and after collision.
    float invincibleDuration;
    bool invincible;

    // These decide whether the player is in range or not.
    public bool inRange;
    public float fireRate;
    public bool evilReload; // Tells the system whether the gun is reloading.

    void Awake()
    {
        globalObject = GameObject.Find("Globals");
        globVars = globalObject.GetComponent<GlobalVariables>();

        maxHealth = (int) globVars.evilHealth;
        maxDamage = (int) globVars.evilDamage;

        currentHealth = maxHealth;
        currentDamage = maxDamage;

        scaleHealth = 0.25f;
        scaleDamage = 0.10f;

        baseTimeAmount = 30.0f;
        timeUntilScale = baseTimeAmount;

        asteroidDamage = maxHealth * 0.25f; // At start, takes quarter damage if hit by asteroid.
        shipDamage = maxHealth * 0.50f; // At start, takes half damage if collides with a ship.

        globVars.evilDamage = currentDamage;

        thisEnemy = this.GetComponent<Transform>();

        leftTurret = transform.Find("leftTurret").gameObject;
        lTurretVars = leftTurret.GetComponent<evilFire>();
        rightTurret = transform.Find("rightTurret").gameObject;
        rTurretVars = rightTurret.GetComponent<evilFire>();

        invincibleDuration = 1.0f;
        invincible = true;

        inRange = false;
        fireRate = 1.0f;
        evilReload = false;
    }

    void Update()
    {
        // Spawn invincibility, only against asteroids for 1 second 
        if (invincible)
        {
            invincibleDuration -= Time.deltaTime;

            if (invincibleDuration <= 0.0f)
                invincible = false;
        }

        // If either the current health or damage somehow exceed the max
        if (currentHealth > maxHealth)
            currentHealth = maxHealth;
        if (currentDamage > maxDamage)
            currentDamage = maxDamage;

        // Countdown every update
        timeUntilScale -= Time.deltaTime;

        // Once countdown reaches zero, upgrade
        if (timeUntilScale <= 0.0f)
        {
            upgradeEnemyStats();
            timeUntilScale = baseTimeAmount;
        }

        // status set in EnemyMovement.cs
        if (inRange && !evilReload)
            StartCoroutine(fireMG());

    }

    void OnCollisionEnter(Collision col)
    {
        if (!invincible)    // Only takes damage when vulnerable.
        {
            globVars = globalObject.GetComponent<GlobalVariables>();    // In case damage has gone up.
            if (col.gameObject.tag == "Asteroid")   // This is just for asteroid damage.
            {
                takeDamage(asteroidDamage);    // Takes asteroid damage.
                
                //  Destroyed if health is zero, and add to global shipScrap count
                if (currentHealth <= 0)
                {
                    globVars.shipScrapsAmount += 1;
                    globVars.score += 1; // Adds one to score for the scrap.
                    Destroy(this.gameObject);   // Dies if it runs out of health.
                }
                else
                {
                    invincible = true;
                }
            }
            // Next section is based on projectile damage.
            else if (col.gameObject.tag == "Bullet")
            {
                takeDamage(globVars.bulletDamage * globVars.damageModifier);
                Destroy(col.gameObject);  // Takes bullet damage.
            }
            else if (col.gameObject.tag == "Rocket")
            {
                takeDamage(globVars.rocketDamage * globVars.damageModifier);
                Destroy(col.gameObject);  // Takes rocket damage.
            }
            else if (col.gameObject.tag == "Shrapnel")
            {
                takeDamage(globVars.shrapnelDamage * globVars.damageModifier);
                Destroy(col.gameObject);    // Takes shrapnel damage.
            }
            else if (col.gameObject.tag == "Evil")
            {
                takeDamage(globVars.evilDamage * globVars.damageModifier);
                Destroy(col.gameObject);    // Takes enemy projectile damage.
            }
            else if (col.gameObject.tag == "Player")    // Occurs when colliding with player ship.
            {
                takeDamage(shipDamage * globVars.damageModifier);
            }
            // Takes ship damage plus the modifier.
            else if (col.gameObject.tag == "Enemy")
            {
                takeDamage(shipDamage);    // Only occurs if it collides with another enemy ship.
            }
            // No other else needed, all collisions are now being considered.
        }
    }

    // Used for the laser damage.
    void OnTriggerEnter(Collider trig)
    {
        globVars = globalObject.GetComponent<GlobalVariables>();    // In case damage has gone up.
        if (trig.gameObject.tag == "Laser")
        {
            for (int i = 0; i < 3; i++) // Deals damage three times...
            {
                takeDamage(globVars.laserDamage * globVars.damageModifier);
            }
            Destroy(trig.gameObject);   // Before laser is destroyed.
        }
        // No need for an else, no other triggers exist.
        if (currentHealth <= 0)
        {
            globVars.shipScrapsAmount += 1;
            globVars.score += 1; // Adds one to score for the scrap.
            Destroy(this.gameObject);   // Destroys if laser wins.
        }
    }

    // Function to receive damage from projectile.
    public void takeDamage(float damage)
    {
        currentHealth -= (int) damage;    // Subtracts the damage.

        //  Destroyed if health is zero, and add to global shipSrap count
        if (currentHealth <= 0.0f)
        {
            globVars.shipScrapsAmount += 1;
            globVars.score += 1; // Adds one to score for the scrap.
            Destroy(this.gameObject);   // Dies if too much damage taken.
        }
    }

    void upgradeEnemyStats()
    {
        // Calculate scaled values from max values
        float healthUp = maxHealth * scaleHealth;
        float damageUp = maxDamage * scaleDamage;

        // Add scaled values to new max values
        maxHealth += (int) healthUp;
        maxDamage += (int) damageUp;

        globVars.evilHealth = maxHealth;    // Carries changes over to new ships that spawn.
        globVars.evilDamage = maxDamage;

        asteroidDamage *= 80.0f;    // Takes 20% less damage from asteroids.
        asteroidDamage = Mathf.Round(asteroidDamage);
        asteroidDamage /= 100;      // Preserves 2 decimals.

        shipDamage *= 80.0f;        // Takes 20% less damade from ships.
        shipDamage = Mathf.Round(shipDamage);
        shipDamage /= 100;          // Preserves 2 decimals.
    }

    public IEnumerator fireMG()
    {
        GameObject newEvl1 = Instantiate(lTurretVars.Evl, leftTurret.transform);    // Grabs l turret stats.
        Rigidbody erb1 = newEvl1.GetComponent<Rigidbody>();   // Gets bullet rigidbody.
        erb1.AddRelativeForce(Vector3.forward * lTurretVars.evlSpd, ForceMode.Impulse);  // Sets bullet in right direction.
        newEvl1.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.

        GameObject newEvl2 = Instantiate(rTurretVars.Evl, rightTurret.transform);    // Grabs r turret stats.
        Rigidbody erb2 = newEvl2.GetComponent<Rigidbody>();   // Gets bullet rigidbody.
        erb2.AddRelativeForce(Vector3.forward * rTurretVars.evlSpd, ForceMode.Impulse);  // Sets bullet in right direction.
        newEvl2.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.

        evilReload = true;
        yield return new WaitForSeconds(fireRate);
        evilReload = false;
    }
}