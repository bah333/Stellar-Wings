﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelChanger : MonoBehaviour
{
    void Update()
    {
        OVRInput.Update();
        if(OVRInput.Get(OVRInput.RawButton.A) || OVRInput.Get(OVRInput.RawButton.X) || Input.GetKey("t"))
        {
            SceneManager.LoadScene("AsteroidScene");    // Starts up the game again.
        }
    }
}
