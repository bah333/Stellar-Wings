﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreTrack : MonoBehaviour
{
    GameObject globalObj;
    public int intScore;
    // Start is called before the first frame update
    void Awake()
    {
        DontDestroyOnLoad(this.gameObject); // Keeps the object safe.
        intScore = 0;
    }

    // Update is called once per frame
    void Update()
    {
        globalObj = GameObject.Find("Globals");
        if(globalObj)
        {
            intScore = globalObj.GetComponent<GlobalVariables>().score;
        }
    }
}