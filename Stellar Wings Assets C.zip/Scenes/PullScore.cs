﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PullScore : MonoBehaviour
{
    GameObject scoreKeep;
    public Text score;
    public int numScore;
    string alphScore;

    void Awake()
    {
        scoreKeep = GameObject.Find("ScoreKeeper");
        if(scoreKeep)
        {
            numScore = scoreKeep.GetComponent<ScoreTrack>().intScore;
        }
        else
        {
            numScore = 0;
        }
        alphScore = numScore.ToString();
        score.text = "Final Score: " + alphScore;
    }
}
