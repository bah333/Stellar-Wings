﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class textChange : MonoBehaviour
{
    public Text HealthText; // Stores the text location.
    public Text ScrapsText;
    public Text ScoreText;
    public Text AtkLvl;
    public Text DefLvl;
    int Health;             // Temporarily holds an int value.
    int Scraps;
    int Score;
    int Atk;
    int Def;

    private string translate;   // Converts ints to strings for display.
    GameObject globals;
    GlobalVariables globVars;   // Pulls the health and scrap info.

    // Start is called before the first frame update
    void Start()
    {
        Health = 3000;
        translate = Health.ToString();
        HealthText.text = "Health: " + translate;   // Sets default for all cockpit text.

        Scraps = 0;
        translate = Scraps.ToString();
        ScrapsText.text = "Scraps: " + translate;

        Score = 0;
        translate = Score.ToString();
        ScoreText.text = "Score: " + translate;

        Atk = 0;
        translate = Atk.ToString();
        AtkLvl.text = "Damage Lvl: " + translate;

        Def = 0;
        translate = Def.ToString();
        DefLvl.text = "Shield Lvl: " + translate;
    }

    // Update is called once per frame
    void Update()
    {
        globals = GameObject.Find("Globals");
        globVars = globals.GetComponent<GlobalVariables>(); // Updates all cockpit text.

        Health = (int) globVars.playerHealth;
        translate = Health.ToString();
        HealthText.text = "Health: " + translate;

        Scraps = (int) globVars.shipScrapsAmount;
        translate = Scraps.ToString();
        ScrapsText.text = "Scraps: " + translate;

        Score = globVars.score;
        translate = Score.ToString();
        ScoreText.text = "Score: " + translate;

        Atk = globVars.damageLevel;
        translate = Atk.ToString();
        AtkLvl.text = "Damage Lvl: " + translate;

        Def = globVars.shieldLevel;
        translate = Def.ToString();
        DefLvl.text = "Shield Lvl: " + translate;
    }
}
