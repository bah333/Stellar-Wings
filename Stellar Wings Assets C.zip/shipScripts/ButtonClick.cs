﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ButtonClick : MonoBehaviour
{
    //Set this in the inspector to add a function that will run if the button is clicked;
    public UnityEvent function;
    public int buttonVar;   // Tells program which coroutine to run.
    private bool pressed = false;
    public GameObject globals;
    public AudioSource click;

    private int gunMode;        // Stores gun state.
    private float gunReload;    // Stores reload rate.
    private int scrapCount;     // Stores amount of scrap.
    private int level;          // Stores level of upgrade.
    private int modifier;       // Stores value of damage modifier.

    void Start()
    {
        globals = GameObject.Find("Globals");
    }

    public void ButtonAction()
    {
        if (!pressed)
        {
            pressed = true;
            click.Play();

            if (buttonVar == 1 || buttonVar == 2 || buttonVar == 3 || buttonVar == 4)
            {
                globals.GetComponent<GlobalVariables>().currentFire = buttonVar;
                switch(buttonVar)
                {
                    case 1:
                        globals.GetComponent<GlobalVariables>().reloadTime = 0.5f;
                        break;
                    case 2:
                        globals.GetComponent<GlobalVariables>().reloadTime = 2.5f;
                        break;
                    case 3:
                        globals.GetComponent<GlobalVariables>().reloadTime = 1.5f;
                        break;
                    case 4:
                        globals.GetComponent<GlobalVariables>().reloadTime = 4.0f;
                        break;
                    default:
                        globals.GetComponent<GlobalVariables>().reloadTime = 0.5f;
                        break;
                }
            }
            else
            {
                if (buttonVar == 5 || buttonVar == 6)
                {
                    scrapCount = globals.GetComponent<GlobalVariables>().shipScrapsAmount;
                    StartCoroutine(upgradeShip(buttonVar, scrapCount, globals));
                }
            }
            transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y - 0.1f, transform.localPosition.z);
            StartCoroutine(ButtonUp());
        }
    }

    private IEnumerator upgradeShip(int mode, int scrap, GameObject g)
    {
        if(scrap >= 5)
        {
            if(mode == 5)   // This is for attack.
            {
                if(g.GetComponent<GlobalVariables>().damageModifier < 2)  // It will eventually peak at level 15.
                {
                    g.GetComponent<GlobalVariables>().shipScrapsAmount -= 5;
                    g.GetComponent<GlobalVariables>().damageModifier += 
                    (g.GetComponent<GlobalVariables>().damageModifier / 20);   // Goes up by 5%.

                    g.GetComponent<GlobalVariables>().damageModifier *= 100;    // Protects 2 decimals.
                    g.GetComponent<GlobalVariables>().damageModifier = 
                    Mathf.Round(g.GetComponent<GlobalVariables>().damageModifier);   // Rounds to 'no decimals.'
                    g.GetComponent<GlobalVariables>().damageModifier /= 100;    // Fixes decimals.
                }
                if(g.GetComponent<GlobalVariables>().damageModifier > 2)    // Stops an overflow.
                    g.GetComponent<GlobalVariables>().damageModifier = 2;
                g.GetComponent<GlobalVariables>().damageLevel += 1;     // Increases level by 1.
            }
            else if(mode == 6)  // This is for defense.
            {
                if(g.GetComponent<GlobalVariables>().shieldModifier > 0.5)  // It will eventually peak at level 14.
                {
                    g.GetComponent<GlobalVariables>().shipScrapsAmount -= 5;
                    g.GetComponent<GlobalVariables>().shieldModifier -= 
                    (g.GetComponent<GlobalVariables>().shieldModifier / 20);    // Goes down by 5%.

                    g.GetComponent<GlobalVariables>().shieldModifier *= 100;    // Protects 2 decimals.
                    g.GetComponent<GlobalVariables>().shieldModifier = 
                    Mathf.Round(g.GetComponent<GlobalVariables>().shieldModifier);   // Rounds to 'no decimals.'
                    g.GetComponent<GlobalVariables>().shieldModifier /= 100;    // Fixes decimals.
                }
                if(g.GetComponent<GlobalVariables>().shieldModifier < 0.5)  // Stops an overflow.
                    g.GetComponent<GlobalVariables>().shieldModifier = 0.5F;
                
                g.GetComponent<GlobalVariables>().shieldLevel += 1;     // Increases level by 1.
            }
        }
        yield return new WaitForSeconds(0.25f);
    }

    private IEnumerator ButtonUp()
    {
        yield return new WaitForSeconds(1.0f);
        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y + 0.1f, transform.localPosition.z);
        pressed = false;
    }
}
