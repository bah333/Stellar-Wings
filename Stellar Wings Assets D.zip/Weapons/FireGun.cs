﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireGun : MonoBehaviour
{
    public GameObject globals;  // Used to store the global object.
    public int currentGun;  // Hold which gun the player is using.
    public float currentTime;   // Hold which reload is being used.

    public GameObject Bul;  // Holds bullet prefab.
    public GameObject Roc;  // Holds rocket prefab.
    public GameObject Sca;  // Holds shrapnel prefab.
    public GameObject Las;  // Holds laser prefab.

    public float bulSpd;    // Holds bullet speed.
    public float rocSpd;    // Holds rocket speed.
    public float scaSpd;    // Holds shrapnel speed.
    public float lasSpd;    // Holds laser speed.

    public AudioSource bulSound;    // Holds Bullet sound.
    public AudioSource rocSound;    // Holds Rocket sound.
    public AudioSource scaSound;    // Holds Scatter sound.
    public AudioSource lasSound;    // Holds Laser sound.

    public GameObject scatterL; // Left Shrapnel Spawn.
    public GameObject scatterR; // Right Shrapnel Spawn.
    public bool reloadGun;      // Ensures that gun won't fire infinitely.

    // Start is called before the first frame update
    void Start()
    {
        globals = GameObject.Find("Globals"); // Grabs the global object ahead of time.
        currentGun = globals.GetComponent<GlobalVariables>().currentFire; // Gets gun.
        currentTime = globals.GetComponent<GlobalVariables>().reloadTime; // Gets reload.
        reloadGun = false;
    }

    void Update()
    {
        OVRInput.Update();
        if((OVRInput.Get(OVRInput.RawButton.LIndexTrigger) || OVRInput.Get(OVRInput.RawButton.RIndexTrigger))
            && !reloadGun)   // Checks for input and that the gun is not reloading.
        {
            currentGun = globals.GetComponent<GlobalVariables>().currentFire; // Gets gun.
            currentTime = globals.GetComponent<GlobalVariables>().reloadTime; // Gets reload.

            if(currentGun == 1)  // Creates bullet.
            {
                bulSound.Play();
                GameObject newBul = Instantiate(Bul, gameObject.transform);
                Rigidbody brb = newBul.GetComponent<Rigidbody>();   // Gets bullet rigidbody.
                brb.AddRelativeForce(Vector3.forward * bulSpd, ForceMode.Impulse);  // Sets bullet in right direction.
                newBul.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.
                StartCoroutine(wait(currentTime));    // Reload pause.
            }
            else if(currentGun == 2) // Creates rocket.
            {
                rocSound.Play();
                GameObject newRoc = Instantiate(Roc, gameObject.transform);
                Rigidbody rrb = newRoc.GetComponent<Rigidbody>();   // Gets rocket rigidbody.
                rrb.AddRelativeForce(gameObject.transform.forward * rocSpd, ForceMode.Impulse);  // Sets rocket in right direction.
                newRoc.transform.SetParent(null);   // Removes parent variable, gives rockets own movement.
                StartCoroutine(wait(currentTime));    // Reload pause.
            }
            else if(currentGun == 3) // Creates shrapnel.
            {
                scaSound.Play();
                GameObject newSca1 = Instantiate(Sca, gameObject.transform);
                Rigidbody srb1 = newSca1.GetComponent<Rigidbody>();   // Gets shrapnel1 rigidbody.
                srb1.AddRelativeForce(Vector3.forward * scaSpd, ForceMode.Impulse);  // Sets shrapnel1 in right direction.
                newSca1.transform.SetParent(null);   // Removes parent variable, gives shrapnel own movement.

                GameObject newSca2 = Instantiate(Sca, scatterL.transform);
                Rigidbody srb2 = newSca2.GetComponent<Rigidbody>();   // Gets shrapnel2 rigidbody.
                srb2.AddRelativeForce(Vector3.forward * scaSpd, ForceMode.Impulse);  // Sets shrapnel2 in right direction.
                newSca2.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.

                GameObject newSca3 = Instantiate(Sca, scatterR.transform);
                Rigidbody srb3 = newSca3.GetComponent<Rigidbody>();   // Gets shrapnel3 rigidbody.
                srb3.AddRelativeForce(Vector3.forward * scaSpd, ForceMode.Impulse);  // Sets shrapnel3 in right direction.
                newSca3.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.

                StartCoroutine(wait(currentTime));    // Reload pause.
            }
            else if(currentGun == 4) // Creates laser.
            {
                lasSound.Play();
                GameObject newLas = Instantiate(Las, gameObject.transform);
                Rigidbody lrb = newLas.GetComponent<Rigidbody>();   // Gets laser rigidbody.
                lrb.AddRelativeForce(Vector3.forward * lasSpd, ForceMode.Impulse);  // Sets laser in right direction.
                newLas.transform.SetParent(null);   // Removes parent variable, gives bullets own movement.
                StartCoroutine(wait(currentTime));    // Reload pause.
            }
        }
    }

    private IEnumerator wait(float time)
    {
        reloadGun = true;
        yield return new WaitForSeconds(time);
        reloadGun = false;
    }
}
