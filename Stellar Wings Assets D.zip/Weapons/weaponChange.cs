﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weaponChange : MonoBehaviour
{
    public GameObject globals = GameObject.Find("Globals");

    void changeWeapon(int mode)
    {
        globals.GetComponent<GlobalVariables>().currentFire = mode;
    }
}
