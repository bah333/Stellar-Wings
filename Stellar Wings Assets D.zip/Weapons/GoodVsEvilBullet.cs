﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoodVsEvilBullet : MonoBehaviour
{
    void onCollisionEnter(Collision col) // Collision between and and evil projectiles.
    {
        if(col.gameObject.tag == "Bullet" || col.gameObject.tag == "Rocket" || 
        col.gameObject.tag == "Shrapnel" || col.gameObject.tag == "Laser")  // Looks for all good projectiles.
        {
            Destroy(col.gameObject);    // Destroys good projectile.
            Destroy(this.gameObject);   // Destroys bad projectile.
        }
    }
}
