﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerStats : MonoBehaviour
{
    // Maximum health value.
    public int maxHealth;

    // Damage taken when colliding with an asteroid or other ships
    public int asteroidDamage;
    public int shipDamage;

    // For global variables
    GameObject globals;
    GlobalVariables globVars;
    public AudioSource danger;

    // For invincibility upon spawn and after collision.
    float invincibleDuration;
    bool invincible;

    void Start()
    {
        globals = GameObject.Find("Globals");
        globVars = globals.GetComponent<GlobalVariables>();

        // Sets player health.
        globVars.playerHealth = 3000;
        maxHealth = 1000;

        asteroidDamage = (int) (maxHealth * 0.20f); // At start, takes 20% damage if hit by asteroid.
        shipDamage = (int) (maxHealth * 0.30f); // At start, takes 30% damage if collides with a ship.

        // States how long the vehicle is invincible for ay any given time.
        invincibleDuration = 2.0f;
        invincible = true;
    }

    void Update()
    {
        // Spawn invincibility, only against asteroids for 1 second 
        if (invincible)
        {
            invincibleDuration -= Time.deltaTime;
            if (invincibleDuration <= 0.0f)
            {
                invincible = false;
            }   
        }

        // If current health somehow exceeds the max
        if (globVars.playerHealth > maxHealth)
            globVars.playerHealth = (int) maxHealth;
    }

    void OnCollisionEnter(Collision col)
    {
        if (!invincible && col.gameObject.tag != "Player")    // Only takes damage when vulnerable.
        {
            danger.Play();
            globVars = globals.GetComponent<GlobalVariables>();    // In case damage rate has changed.
            if (col.gameObject.tag == "Asteroid")   // This is just for asteroid damage.
            {
                takeDamage(asteroidDamage * globVars.shieldModifier);
                // Takes asteroid damage, lessened by levels in shield.
                
                //  Destroyed if health is zero, cuts to a game over screen.
                if (globVars.playerHealth <= 0)
                {
                    Destroy(this.gameObject);   // Dies if it runs out of health.
                    SceneManager.LoadScene("GameOverScreen");   // Moves player to game over screen post-damage.
                }
                else
                {
                    invincible = true;  // Turns invincibility back on for a bit.
                    invincibleDuration = 2.0f;  // Resets invincibility timer fully.
                }
            }
            // Next section is based on evil bullet damage.
            else if (col.gameObject.tag == "Evil")
            {
                takeDamage(globVars.evilDamage * globVars.shieldModifier);
                Destroy(col.gameObject);  // Takes bullet damage.
            }

            else if (col.gameObject.tag == "Enemy")   // Occurs exclusively with enemy ships.
            {
                takeDamage(shipDamage * globVars.shieldModifier);
                // Takes ship contact damage, lessened by levels in shield.
            }

            // No else needed, every other collision is excluded and is unaffected by triggers.

            //  Destroyed if health is zero, cuts to a game over screen.
            if (globVars.playerHealth <= 0.0f)
            {
                Destroy(this.gameObject);   // Dies if too much damage taken.
                SceneManager.LoadScene("GameOverScreen");   // Moves player to game over screen post-damage.
            }
            else
            {
                invincible = true;  // Turns invincibility back on for a bit.
                invincibleDuration = 1.0f;  // Resets invincibility timer halfway.
            }
        }
    }

    // Used to circumvent potential laser triggers.
    void OnTriggerEnter(Collider trig)
    {
        if (trig.gameObject.tag == "Laser")
        {
            Destroy(trig.gameObject);   // Gets rid of laser instead of taking damage.
        }
    }

    // Function to receive damage from projectile.
    public void takeDamage(float damage)
    {
        globVars.playerHealth -= (int) damage;    // Subtracts the damage.
    }
}