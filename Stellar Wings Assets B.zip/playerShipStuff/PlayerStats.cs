﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    // Maximum health value.
    public float maxHealth;

    // Current health at whatever time
    float currentHealth;

    // Countdown timer for ???
    float timeUntilScale;
    public float baseTimeAmount;

    // Damage taken when colliding with an asteroid or other ships
    public float asteroidDamage;
    public float shipDamage;

    // For global variables
    GameObject globals;
    GlobalVariables globVars;

    // For invincibility upon spawn and after collision.
    float invincibleDuration;
    bool invincible;

    void Awake()
    {
        globals = GameObject.Find("Globals");
        globVars = globals.GetComponent<GlobalVariables>();

        // Sets player health.
        maxHealth = globVars.playerHealth;
        currentHealth = maxHealth;

        // asteroidDamage = 100.0f;
        asteroidDamage = maxHealth * 0.30f; // At start, takes 15% damage if hit by asteroid.
        shipDamage = maxHealth * 0.30f; // At start, takes 30% damage if collides with a ship.

        // States how long the vehicle is invincible for ay any given time.
        invincibleDuration = 2.0f;
        invincible = true;
    }

    void Update()
    {
        // Spawn invincibility, only against asteroids for 1 second 
        if (invincible)
        {
            invincibleDuration -= Time.deltaTime;
            if (invincibleDuration <= 0.0f)
            {
                invincible = false;
            }   
        }

        // If current health somehow exceeds the max
        if (currentHealth > maxHealth)
            currentHealth = maxHealth;
    }

    void OnCollisionEnter(Collision col)
    {
        if (!invincible)    // Only takes damage when vulnerable.
        {
            globVars = globals.GetComponent<GlobalVariables>();    // In case damage rate has changed.
            if (col.gameObject.tag == "Asteroid")   // This is just for asteroid damage.
            {
                currentHealth -= (asteroidDamage * globVars.shieldModifier);
                // Takes asteroid damage, lessened by levels in shield.
                currentHealth = Mathf.Round(currentHealth); // Rounds health to whole number.
                
                //  Destroyed if health is zero, cuts to a game over screen.
                if (currentHealth <= 0)
                {
                    Destroy(this.gameObject);   // Dies if it runs out of health.
                    // ADD GAME OVER SCENE JUMP.
                }
                else
                {
                    invincible = true;  // Turns invincibility back on for a bit.
                    invincibleDuration = 2.0f;  // Resets invincibility timer fully.
                }
            }
            // Next section is based on evil bullet damage.
            else if (col.gameObject.tag == "Evil")
            {
                takeDamage(globVars.evilDamage * globVars.shieldModifier);
                Destroy(col.gameObject);  // Takes bullet damage.
            }

            else if (col.gameObject.tag == "Enemy")   // Occurs exclusively with enemy ships.
            {
                currentHealth -= (shipDamage * globVars.shieldModifier);
                // Takes ship contact damage, lessened by levels in shield.
            }

            // No else needed, every other collision is excluded and is unaffected by triggers.

            //  Destroyed if health is zero, cuts to a game over screen.
            if (currentHealth <= 0.0f)
            {
                Destroy(this.gameObject);   // Dies if too much damage taken.
                // ADD GAME OVER SCENE JUMP.
            }
        }
    }

    // Used to circumvent potential laser triggers.
    void OnTriggerEnter(Collider trig)
    {
        if (trig.gameObject.tag == "Laser")
        {
            Destroy(trig.gameObject);   // Gets rid of laser instead of taking damage.
        }
    }

    // Function to receive damage from projectile.
    public void takeDamage(float damage)
    {
        currentHealth -= damage;    // Subtracts the damage.
    }
}